<?php
class Master extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('model_master');
        $this->load->helper('currency_format_helper');
    }

    function index(){
        $data=array(
            'title'=>'Master Data',
            'active_master'=>'active',
            'kd_barang'=>$this->model_master->getKodeBarang(),
            'kd_pelanggan'=>$this->model_master->getKodePelanggan(),
            'kd_pegawai'=>$this->model_master->getKodePegawai(),
            'data_barang'=>$this->model_master->getAllBarang(),
            'data_pelanggan'=>$this->model_master->getAllPelanggan(),
            'data_contact'=>$this->model_master->getAllContact(),
            'data_pegawai'=>$this->model_master->getAllPegawai(),
        );
        $this->load->view('element/v_header',$data);
        $this->load->view('pages/v_master');
        $this->load->view('element/v_footer');
    }

//
//    ===================== INSERT =====================
    function tambah_barang(){
        $data=array(
            'kd_barang'=> $this->model_master->getKodeBarang(),
            'nm_barang'=>$this->input->post('nm_barang'),
            'stok'=>$this->input->post('stok'),
            'harga'=>$this->input->post('harga'),
        );
        $this->model_master->insertBarang($data);
        redirect("master");
    }
    function tambah_pelanggan(){
        $data=array(
            'kd_pelanggan'=> $this->model_master->getKodePelanggan(),
            'nm_pelanggan'=>$this->input->post('nm_pelanggan'),
            'alamat'=>$this->input->post('alamat'),
            'email'=>$this->input->post('email'),
        );
        $this->model_master->insertPelanggan($data);
        redirect("master");
    }
    function tambah_pegawai(){
        $data=array(
            'kd_pegawai'=> $this->model_master->getKodePegawai(),
            'username'=>$this->input->post('username'),
            'password'=>md5($this->input->post('password')),
            'nama'=> $this->input->post('nama'),
            'level'=>$this->input->post('level'),
        );
        $this->model_master->insertPegawai($data);
        redirect("master");
    }


//    ======================== EDIT =======================
    function edit_barang(){
        $id = $this->input->post('kd_barang');
        $data=array(
            'kd_barang'=> $this->input->post('kd_barang'),
            'nm_barang'=>$this->input->post('nm_barang'),
            'stok'=>$this->input->post('stok'),
            'harga'=>$this->input->post('harga'),
        );
        $this->model_master->updateBarang($id,$data);
        redirect("master");
    }
    function edit_pelanggan(){
        $id = $this->input->post('kd_pelanggan');
        $data=array(
            'kd_pelanggan'=> $this->input->post('kd_pelanggan'),
            'nm_pelanggan'=>$this->input->post('nm_pelanggan'),
            'alamat'=>$this->input->post('alamat'),
            'email'=>$this->input->post('email'),
        );
        $this->model_master->updatePelanggan($id,$data);
        redirect("master");
    }
    function edit_contact(){
        $id = $this->input->post('id');
        $data=array(
            'nama'=> $this->input->post('nama'),
            'owner'=>$this->input->post('owner'),
            'alamat'=>$this->input->post('alamat'),
            'telp'=>$this->input->post('telp'),
            'email'=>$this->input->post('email'),
            'website'=>$this->input->post('website'),
            'desc'=>$this->input->post('desc'),
        );
        $this->model_master->updateContact($id,$data);
        redirect("master");
    }
    function edit_pegawai(){
        $id = $this->input->post('kd_pegawai');
        $data=array(
            'username'=>$this->input->post('username'),
            'password'=>md5($this->input->post('password')),
            'nama'=> $this->input->post('nama'),
            'level'=>$this->input->post('level'),
        );
        $this->model_master->updatePegawai($id,$data);
        redirect("master");
    }

//    ========================== DELETE =======================
    function hapus_barang(){
        $id = $this->uri->segment(3);
        $this->model_master->deleteBarang($id);
        redirect("master");
    }
    function hapus_pelanggan(){
        $id = $this->uri->segment(3);
        $this->model_master->deletePelanggan($id);
        redirect("master");
    }
    function hapus_pegawai(){
        $id = $this->uri->segment(3);
        $this->model_master->deletePegawai($id);
        redirect("master");
    }
}


