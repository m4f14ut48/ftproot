<hr>
        <div class="footer">
            <p>&copy; Created By : <a href="http://facebook.com/gilang.sonar" target="_blank"><strong>GilangSonar</strong></a></p>
        </div>

<script type="text/javascript" src="<?php echo base_url('asset/js/jquery.printPage.js')?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(".btnPrint").printPage();
    })
</script>

    </div>
</body>

